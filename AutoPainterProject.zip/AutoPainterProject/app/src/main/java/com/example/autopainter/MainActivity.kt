package com.example.autopainter

import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import android.provider.Settings
import java.io.File
import java.io.FileOutputStream

class MainActivity : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        if (intent?.action == Intent.ACTION_SEND) {
            val uri = intent.getParcelableExtra<Uri>(Intent.EXTRA_STREAM)
            uri?.let { saveTempAndStartOverlay(it) }
        }

        findViewById<Button>(R.id.btnStartOverlay).setOnClickListener {
            if (!Settings.canDrawOverlays(this)) {
                val i = Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName"))
                startActivity(i)
            } else {
                val svc = Intent(this, FloatingService::class.java)
                ContextCompat.startForegroundService(this, svc)
                finish()
            }
        }

        findViewById<Button>(R.id.btnPick).setOnClickListener {
            val pick = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
            startActivityForResult(pick, 2001)
        }
    }

    private fun saveTempAndStartOverlay(uri: Uri) {
        val `is` = contentResolver.openInputStream(uri) ?: return
        val out = File(cacheDir, "shared_input.png")
        FileOutputStream(out).use { it.write(`is`.readBytes()) }
        `is`.close()
        val svc = Intent(this, FloatingService::class.java).apply {
            putExtra("image_path", out.absolutePath)
        }
        ContextCompat.startForegroundService(this, svc)
        finish()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 2001 && resultCode == Activity.RESULT_OK) {
            data?.data?.let { saveTempAndStartOverlay(it) }
        }
    }
}
