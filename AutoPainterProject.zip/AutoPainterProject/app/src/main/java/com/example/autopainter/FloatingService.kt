package com.example.autopainter

import android.app.Service
import android.content.Intent
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.Toast

class FloatingService : Service() {
    private lateinit var windowManager: WindowManager
    private var floatView: View? = null
    private var imagePath: String? = null

    override fun onCreate() {
        super.onCreate()
        windowManager = getSystemService(WINDOW_SERVICE) as WindowManager
        createOverlay()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        imagePath = intent?.getStringExtra("image_path")
        return START_STICKY
    }

    private fun createOverlay() {
        val layoutParams = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O)
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
            else
                WindowManager.LayoutParams.TYPE_PHONE,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE,
            PixelFormat.TRANSLUCENT
        )
        layoutParams.gravity = Gravity.TOP or Gravity.START
        floatView = LayoutInflater.from(this).inflate(R.layout.layout_floating, null)
        val btnStart = floatView!!.findViewById<Button>(R.id.btnAutoPaint)
        btnStart.setOnClickListener {
            imagePath?.let {
                Thread {
                    val strokes = ImageProcessor(this).processImageToStrokes(it)
                    // write strokes to cache file and broadcast path
                    val out = File(cacheDir, "strokes.json")
                    out.writeText(StrokeSerializer.serialize(strokes))
                    val b = Intent("com.example.autopainter.ACTION_START_PAINT")
                    b.putExtra("strokes_path", out.absolutePath)
                    sendBroadcast(b)
                }.start()
            } ?: run {
                Toast.makeText(this, "No image provided", Toast.LENGTH_SHORT).show()
            }
        }
        windowManager.addView(floatView, layoutParams)
    }

    override fun onBind(intent: Intent?) = null

    override fun onDestroy() {
        super.onDestroy()
        floatView?.let { windowManager.removeView(it) }
    }
}
