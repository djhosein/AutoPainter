package com.example.autopainter

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import kotlin.math.min
import kotlin.math.sqrt

data class PointF(val x: Float, val y: Float)
data class Stroke(val points: List<PointF>, val duration: Long)

object StrokeSerializer {
    // Very simple JSON serializer/deserializer to pass strokes via file
    fun serialize(list: List<Stroke>): String {
        val arr = list.map { s ->
            val pts = s.points.map { p -> listOf(p.x, p.y) }
            mapOf("pts" to pts, "d" to s.duration)
        }
        return kotlinx.serialization.json.Json.encodeToString(arr)
    }
    fun deserialize(json: String): List<Stroke> {
        val parsed = kotlinx.serialization.json.Json.parseToJsonElement(json)
        val out = mutableListOf<Stroke>()
        if (parsed is kotlinx.serialization.json.JsonArray) {
            for (el in parsed) {
                val obj = el.jsonObject
                val d = obj["d"]!!.jsonPrimitive.long
                val pts = obj["pts"]!!.jsonArray.map {
                    val p = it.jsonArray
                    PointF(p[0].jsonPrimitive.float, p[1].jsonPrimitive.float)
                }
                out.add(Stroke(pts, d))
            }
        }
        return out
    }
}

class ImageProcessor(private val context: Context) {

    fun processImageToStrokes(path: String): List<Stroke> {
        val bmp = BitmapFactory.decodeFile(path) ?: return emptyList()
        val scaled = Bitmap.createScaledBitmap(bmp, bmp.width / 2, bmp.height / 2, true)
        val gray = toGrayscale(scaled)
        val edges = simpleEdgeDetect(gray)
        val skeleton = edges // placeholder for thinning
        val paths = tracePaths(skeleton)
        return paths.map { pts ->
            val screenPts = pts.map { p -> PointF(p.first.toFloat(), p.second.toFloat()) }
            Stroke(screenPts, (screenPts.size * 5).toLong())
        }
    }

    private fun toGrayscale(b: Bitmap): Bitmap {
        val w=b.width; val h=b.height
        val out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        for (y in 0 until h) for (x in 0 until w) {
            val c = b.getPixel(x,y)
            val r=Color.red(c); val g=Color.green(c); val bl=Color.blue(c)
            val v=(0.3*r + 0.59*g + 0.11*bl).toInt()
            out.setPixel(x,y, Color.rgb(v,v,v))
        }
        return out
    }

    private fun simpleEdgeDetect(b: Bitmap): Bitmap {
        val w=b.width; val h=b.height
        val out=Bitmap.createBitmap(w,h,Bitmap.Config.ARGB_8888)
        val gx = arrayOf(intArrayOf(-1,0,1), intArrayOf(-2,0,2), intArrayOf(-1,0,1))
        val gy = arrayOf(intArrayOf(-1,-2,-1), intArrayOf(0,0,0), intArrayOf(1,2,1))
        for (y in 1 until h-1) {
            for (x in 1 until w-1) {
                var sx=0; var sy=0
                for (ky in 0..2) for (kx in 0..2) {
                    val px = b.getPixel(x+kx-1, y+ky-1)
                    val v = Color.red(px)
                    sx += gx[ky][kx]*v
                    sy += gy[ky][kx]*v
                }
                val mag = min(255, sqrt((sx*sx + sy*sy).toDouble()).toInt())
                val c = if (mag > 50) 0x00 else 0xFF
                out.setPixel(x,y, Color.rgb(c,c,c))
            }
        }
        return out
    }

    private fun tracePaths(b: Bitmap): List<List<Pair<Int,Int>>> {
        val w=b.width; val h=b.height
        val visited = Array(h) { BooleanArray(w) }
        val paths = mutableListOf<List<Pair<Int,Int>>>()
        for (y in 0 until h) for (x in 0 until w) {
            if (!visited[y][x] && Color.red(b.getPixel(x,y)) == 0) {
                val stack = ArrayDeque<Pair<Int,Int>>()
                val pts = mutableListOf<Pair<Int,Int>>()
                stack.add(Pair(x,y)); visited[y][x]=true
                while (stack.isNotEmpty()) {
                    val p = stack.removeFirst()
                    pts.add(p)
                    for (dy in -1..1) for (dx in -1..1) {
                        val nx = p.first + dx; val ny = p.second + dy
                        if (nx in 0 until w && ny in 0 until h && !visited[ny][nx]) {
                            if (Color.red(b.getPixel(nx,ny)) == 0) {
                                visited[ny][nx]=true
                                stack.add(Pair(nx,ny))
                            }
                        }
                    }
                }
                if (pts.size > 10) paths.add(pts)
            }
        }
        return paths
    }
}
