package com.example.autopainter

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Path
import android.util.Log

class AutoPainterAccessibilityService : AccessibilityService() {

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent?.action == "com.example.autopainter.ACTION_START_PAINT") {
                val path = intent.getStringExtra("strokes_path") ?: return
                val file = java.io.File(path)
                if (!file.exists()) return
                val serialized = file.readText()
                val strokes = StrokeSerializer.deserialize(serialized)
                startPainting(strokes)
            }
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        registerReceiver(receiver, IntentFilter("com.example.autopainter.ACTION_START_PAINT"))
    }

    override fun onAccessibilityEvent(event: android.view.accessibility.AccessibilityEvent?) {}
    override fun onInterrupt() {}

    private fun startPainting(strokes: List<Stroke>) {
        var totalDelay = 0L
        for (s in strokes) {
            if (s.points.isEmpty()) continue
            val path = Path()
            path.moveTo(s.points[0].x, s.points[0].y)
            for (p in s.points.drop(1)) path.lineTo(p.x, p.y)

            val desc = GestureDescription.Builder()
                .addStroke(GestureDescription.StrokeDescription(path, totalDelay, s.duration))
                .build()

            dispatchGesture(desc, object : GestureDescription.GestureResultCallback() {
                override fun onCompleted(gestureDescription: GestureDescription?) {
                    super.onCompleted(gestureDescription)
                }
                override fun onCancelled(gestureDescription: GestureDescription?) {
                    super.onCancelled(gestureDescription)
                }
            }, null)

            totalDelay += s.duration + 50L
        }
    }

    override fun onUnbind(intent: Intent?): Boolean {
        unregisterReceiver(receiver)
        return super.onUnbind(intent)
    }
}
